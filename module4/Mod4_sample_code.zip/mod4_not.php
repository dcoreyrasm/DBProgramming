<?php
$variable1 = 100;

if ($variable1 !== 90) {
    echo "Hello world!";
?>
