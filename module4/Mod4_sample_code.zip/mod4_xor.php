<?php
$variable1 = 100;
$variable2 = 50;

if ($variable1 == 100 xor $variable2 == 50) {
    echo "Hello world!";
}
?>
