
<?php
//float example
$samplevariable = 2017.465;
var_dump($samplevariable);

?>
