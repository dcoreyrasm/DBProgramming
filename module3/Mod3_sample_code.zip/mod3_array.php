
<?php
//array example
$colors = array("Red","Blue","Purple");
var_dump($colors);

?>
