
<?php
//integer example
$samplevariable = 2017;
var_dump($samplevariable);

?>
